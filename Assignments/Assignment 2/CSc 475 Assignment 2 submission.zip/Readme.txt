CSC 475 - Assignment 2

Zip file contains python notebook and PDF print copy of the same notebook

PDF is provided as one of the run times of the cells in A2.4 of the jupyter notebook takes 9 mins